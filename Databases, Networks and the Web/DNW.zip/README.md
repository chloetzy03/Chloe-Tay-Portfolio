##  Coursework Template ##
### CM2040 Database Networks and the Web ###


#### Using this application ####
To get started:

* Run ```npm install``` from the project directory to install all the node packages.

* Run ```npm run build-db``` to create the database on Mac or Linux 
or run ```npm run build-db-win``` to create the database on Windows

* Run ```npm run start``` to start serving the web app (Access via http://localhost:3000)

1. Register a new organiser account 
2. Log in as an organiser
3. Create and manage events
4. View events as an attendee
5. Book an event as an attendee

#### Additional Libraries ####
These are automatically installed via npm install:
- bcrypt
- express-session 
- connect-flash 
- dotenv 
- ejs  
- express 
- sqlite3 

