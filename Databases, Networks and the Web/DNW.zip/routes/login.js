const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const SALT_ROUNDS = 10; // Number of rounds for bcrypt hashing

// Render organiser registration page
router.get("/register", (req, res) => {
    res.render("organiser-register", { error: null });
});

// Handle organiser registration form submission
router.post("/register", async (req, res) => {
    const { username, password } = req.body;
    // Ensure both fields are filled
    if (!username || !password) {
        return res.render("organiser-register", { error: "Username and password are required." });
    }

    try {
        // Check if username already exists
        global.db.get("SELECT * FROM organisers WHERE username = ?", [username], async (err, existing) => {
            if (err) {
                console.error(err);
                return res.render("organiser-register", { error: "Internal server error." });
            }

            if (existing) {
                return res.render("organiser-register", { error: "Username already taken." });
            }
            // Hash the password before saving
            const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

            // Insert new organiser into organiser table
            const insertOrgQuery = `
                INSERT INTO organisers (username, password, organisation_name)
                VALUES (?, ?, ?)
            `;
            global.db.run(insertOrgQuery, [username, hashedPassword, username], function (err) {
                if (err) {
                    console.error(err);
                    return res.render("organiser-register", { error: "Registration failed." });
                }

                const newOrganiserId = this.lastID;

                // Create default site settings
                const insertSettings = `
                    INSERT INTO site_settings (organiser_id, site_name, site_description)
                    VALUES (?, ?, ?)
                `;
                global.db.run(insertSettings, [newOrganiserId, username, "This is your site. You can edit it later."], (err) => {
                    if (err) {
                        console.error(err);
                        return res.render("organiser-register", { error: "Failed to set up site settings." });
                    }


                    //redirect user to login page to login again
                    req.flash("success", "Registration successful! You may now log in.");
                    res.redirect("/organiser/login");

                });
            });
        });
    } catch (err) {
        console.error(err);
        res.render("organiser-register", { error: "Something went wrong." });
    }
});

// Render the organiser login page
router.get("/login", (req, res) => {
    res.render("organiser-login");
});


const sqlite3 = require("sqlite3").verbose();

// Handle login form submission
router.post("/login", (req, res) => {
    const { username, password } = req.body;
    // Fetch organiser details from DB using username
    const query = `SELECT * FROM organisers WHERE username = ?`;

    global.db.get(query, [username], async (err, organiser) => {
        if (err) {
            console.error("DB error:", err);
            req.flash("error", "Internal server error.");
            return res.redirect("/organiser/login");
        }

        if (!organiser) {
            req.flash("error", "Incorrect username or password.");
            return res.redirect("/organiser/login");
        }
        // Compare hashed password with input password
        const match = await bcrypt.compare(password, organiser.password);
        if (!match) {
            req.flash("error", "Incorrect username or password.");
            return res.redirect("/organiser/login");
        }

        req.session.isOrganiser = true;
        req.session.organiserId = organiser.id;
        req.session.organisationName = organiser.organisation_name;
        res.redirect("/organiser");
    });
});



//middleware
router.use((req, res, next) => {
  if (req.session.isOrganiser || req.path === '/login') {
    return next();
  }
  return res.redirect("/organiser/login");
});

// Logout route
router.get("/logout", (req, res) => {
    req.session.destroy(() => {
        res.redirect("/organiser/login");
    });
});


module.exports = router;


