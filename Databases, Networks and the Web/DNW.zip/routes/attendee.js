// routes/attendee.js
const express = require("express");
const router = express.Router();

/**
 * @desc Attendee Home Page
 * Shows all published events
 */
router.get("/", function (req, res, next) {
    const query = `
        SELECT 
            events.*, 
            site_settings.site_name,
            site_settings.site_description
        FROM events
        JOIN site_settings ON events.organiser_id = site_settings.organiser_id
        WHERE events.status = 'published'
        ORDER BY site_settings.site_name ASC, events.date ASC
    `;

    global.db.all(query, function (err, rows) {
        if (err) return next(err);

        // Group events by organiser (site_name , site_description)
        const groupedEvents = {};
        rows.forEach(event => {
            const key = `${event.site_name}|||${event.site_description}`; // Combine as a unique key
            if (!groupedEvents[key]) {
                groupedEvents[key] = [];
            }
            groupedEvents[key].push(event);
        });

        res.render("attendee-home", { groupedEvents });
    });
});



/**
 * @desc View indiv event
 */
router.get("/event/:id", function (req, res, next) {
    const query = "SELECT * FROM events WHERE id = ? AND status = 'published'";

    global.db.get(query, [req.params.id], function (err, event) {
        if (err) {
            next(err);
        } else if (!event) {
            res.status(404).send("Event not found or not published");
        } else {
            res.render("attendee-event", { event });
        }
    });
});

/**
 * @desc Book tickets for an event
 */
router.post("/event/:id/book", function (req, res, next) {
    const eventId = req.params.id;
    const name = req.body.attendee_name?.trim();
    const fullRaw = req.body.full_price_qty;
    const concessionRaw = req.body.concession_qty;

    // Reject if inputs are blank, non-numeric, or negative
    const fullQty = parseInt(fullRaw, 10);
    const concessionQty = parseInt(concessionRaw, 10);


    if (
        isNaN(fullQty) && isNaN(concessionQty) || // both empty or non-numeric
        (fullQty <= 0 && concessionQty <= 0) ||    // both zero or less
        fullQty < 0 || concessionQty < 0
    ) {
        req.flash("error", "Please enter a valid number of tickets.");
        return res.redirect(`/attendee/event/${eventId}`);
    }

    const bookedAt = new Date().toISOString();

    const getEventQuery = "SELECT * FROM events WHERE id = ? AND status = 'published'";
    global.db.get(getEventQuery, [eventId], function (err, event) {
        if (err) {
            next(err);
        } else if (!event) {
            res.status(404).send("Event not found or not published");
        } else {
            // Validate ticket availability
            const enoughFull = !isNaN(fullQty) && fullQty <= event.full_price_tickets;
            const enoughConcession = !isNaN(concessionQty) && concessionQty <= event.concession_tickets;

            if (!enoughFull || !enoughConcession) {
                req.flash("error", "Not enough tickets available.");
                return res.redirect(`/attendee/event/${eventId}`);
            }

            // Proceed to insert booking
            const insertQuery = `
                INSERT INTO bookings (event_id, attendee_name, full_price_qty, concession_qty, booked_at)
                VALUES (?, ?, ?, ?, ?)
            `;

            global.db.run(insertQuery, [eventId, name, fullQty || 0, concessionQty || 0, bookedAt], function (err) {
                if (err) {
                    next(err);
                } else {
                    const updateQuery = `
                        UPDATE events
                        SET
                            full_price_tickets = full_price_tickets - ?,
                            concession_tickets = concession_tickets - ?
                        WHERE id = ?
                    `;

                    global.db.run(updateQuery, [fullQty || 0, concessionQty || 0, eventId], function (err) {
                        if (err) {
                            next(err);
                        } else {
                            
                            req.flash("success", "Tickets successfully booked!");
                            res.redirect(`/attendee/event/${eventId}`);
                        }
                    });
                }
            });
        }
    });
});


module.exports = router;
