const express = require("express");
const router = express.Router();

/**
 * @desc Format timestamp 
 */
function formatTimestamp(ts) {
    return new Date(ts).toLocaleString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
    });
}

/**
 * @desc Organiser Home Page
 * Shows site settings and separates published/draft events
 */
router.get("/", function (req, res, next) {
    const settingsQuery = "SELECT * FROM site_settings WHERE organiser_id = ?;";
    const eventsQuery = `
        SELECT events.*, 
            (SELECT COUNT(*) FROM bookings WHERE bookings.event_id = events.id) AS booking_count
        FROM events
        WHERE organiser_id = ?
        ORDER BY created_at DESC;
    `;

    const organiserId = req.session.organiserId;
    global.db.get(settingsQuery, [organiserId], function (err, settings) {
        if (err) return next(err);
        global.db.all(eventsQuery, [organiserId], function (err, rows) {
            if (err) return next(err);

            // Apply date formatting
            rows.forEach(event => {
                if (event.created_at) event.created_at = formatTimestamp(event.created_at);
                if (event.published_at) event.published_at = formatTimestamp(event.published_at);
                if (event.last_modified) event.last_modified = formatTimestamp(event.last_modified);
            });

            const published = rows.filter(e => e.status === "published");
            const drafts = rows.filter(e => e.status === "draft");

            res.render("organiser-home", {
                site: settings,
                publishedEvents: published,
                draftEvents: drafts
            });
        });
    });
});

/**
 * @desc View and edit site-wide settings
 */
router.get("/settings", function (req, res, next) {
    const organiserId = req.session.organiserId;
    const query = "SELECT * FROM site_settings WHERE organiser_id = ?";
    global.db.get(query, [organiserId], function (err, row) {
        if (err) return next(err);
        res.render("site-settings", { site: row });
    });
});



/**
 * @desc Create a new draft event and redirect to its edit page
 */
router.post("/create-event", function (req, res, next) {
    const now = new Date().toISOString();
    const organiserId = req.session.organiserId;

    const query = `
        INSERT INTO events (
            organiser_id,
            title, description, date,
            full_price_tickets, concession_tickets,
            full_price_cost, concession_cost,
            created_at, last_modified, status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const params = [
        organiserId,
        "Untitled Event", "", "", // title, description, date
        0, 0,                    // tickets
        0.0, 0.0,                // costs
        now, now,               // created_at, last_modified
        "draft"
    ];

    global.db.run(query, params, function (err) {
        if (err) return next(err);
        const newEventId = this.lastID;
        res.redirect(`/organiser/edit-event/${newEventId}`);
    });
});





/**
 * @desc View the event editing form
 */
router.get("/edit-event/:id", function (req, res, next) {
    const organiserId = req.session.organiserId;
    const query = "SELECT * FROM events WHERE id = ? AND organiser_id = ?";
    global.db.get(query, [req.params.id, organiserId], function (err, event) {
        if (err) return next(err);
        if (!event) return res.status(403).send("Not authorized to view this event");

        // Format timestamps before rendering
        if (event.created_at) event.created_at = formatTimestamp(event.created_at);
        if (event.last_modified) event.last_modified = formatTimestamp(event.last_modified);
        res.render("organiser-edit-event", { event });
    });
});



/**
 * @desc Publish an event by updating its status and timestamps
 */
router.post("/publish-event/:id", function (req, res, next) {
    const organiserId = req.session.organiserId;
    const now = new Date().toISOString();
    const query = `
        UPDATE events
        SET status = 'published',
            published_at = ?,
            last_modified = ?
        WHERE id = ? AND organiser_id = ?
    `;
    global.db.run(query, [now, now, req.params.id, organiserId], function (err) {
        if (err) return next(err);
        res.redirect("/organiser");
    });
});


/**
 * @desc Delete an event by ID
 */
router.post("/delete-event/:id", function (req, res, next) {
    const organiserId = req.session.organiserId;
    const query = `DELETE FROM events WHERE id = ? AND organiser_id = ?`;
    global.db.run(query, [req.params.id, organiserId], function (err) {
        if (err) return next(err);
        res.redirect("/organiser");
    });
});



/**
 * @desc Update event details from the edit form
 */
router.post("/edit-event/:id", function (req, res, next) {
    const now = new Date().toISOString();
    const organiserId = req.session.organiserId;
    const query = `
        UPDATE events
        SET title = ?, description = ?, date = ?,
            full_price_tickets = ?, concession_tickets = ?,
            full_price_cost = ?, concession_cost = ?,
            last_modified = ?
        WHERE id = ? AND organiser_id = ?
    `;
    const params = [
        req.body.title,
        req.body.description,
        req.body.date,
        parseInt(req.body.full_price_tickets),
        parseInt(req.body.concession_tickets),
        parseFloat(req.body.full_price_cost),
        parseFloat(req.body.concession_cost),
        now,
        req.params.id,
        organiserId
    ];

    global.db.run(query, params, function (err) {
        if (err) return next(err);
        res.redirect("/organiser");
    });
});



/**
 * @desc Update site name and description from settings form
 */
router.post("/settings", function (req, res, next) {
    const organiserId = req.session.organiserId;
    const query = `
        UPDATE site_settings
        SET site_name = ?, site_description = ?
        WHERE organiser_id = ?
    `;
    const params = [req.body.site_name, req.body.site_description, organiserId];
    global.db.run(query, params, function (err) {
        if (err) return next(err);
        res.redirect("/organiser");
    });
});


module.exports = router;
