
-- This makes sure that foreign_key constraints are observed and that errors will be thrown for violations
PRAGMA foreign_keys=ON;

BEGIN TRANSACTION;

-- Create your tables with SQL commands here (watch out for slight syntactical differences with SQLite vs MySQL)


-- organiser table
CREATE TABLE IF NOT EXISTS organisers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    organisation_name TEXT NOT NULL
);

-- site_settings table (one per organiser)
CREATE TABLE IF NOT EXISTS site_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    organiser_id INTEGER NOT NULL,
    site_name TEXT NOT NULL,
    site_description TEXT NOT NULL,
    FOREIGN KEY (organiser_id) REFERENCES organisers(id) ON DELETE CASCADE
);

INSERT OR IGNORE INTO site_settings (id, site_name, site_description)
VALUES (1, 'Stretch Yoga', 'Yoga classes for all ages and abilities');

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    organiser_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    date TEXT,
    full_price_tickets INTEGER,
    concession_tickets INTEGER,
    full_price_cost REAL,
    concession_cost REAL,
    created_at TEXT,
    published_at TEXT,
    last_modified TEXT,
    status TEXT CHECK (status IN ('draft', 'published')) NOT NULL,
    FOREIGN KEY (organiser_id) REFERENCES organisers(id) ON DELETE CASCADE
);


CREATE TABLE bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER,
    attendee_name TEXT NOT NULL,
    full_price_qty INTEGER,
    concession_qty INTEGER,
    booked_at TEXT,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
);

-- -- Add demo organisers
-- INSERT INTO organisers (username, password, organisation_name)
-- VALUES ('yoga_admin', 'passyoga', 'Stretch Yoga'),
--        ('gym_admin', 'passgym', 'Power Gym');

-- -- Add site settings for both
-- INSERT INTO site_settings (organiser_id, site_name, site_description)
-- VALUES (1, 'Stretch Yoga', 'Yoga classes for all ages and abilities'),
--        (2, 'Power Gym', 'Strength and Conditioning for all');




COMMIT;

